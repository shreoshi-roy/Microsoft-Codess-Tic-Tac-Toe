from django.apps import AppConfig


class TictactoeConfig(AppConfig):
    name = 'tictactoe'
